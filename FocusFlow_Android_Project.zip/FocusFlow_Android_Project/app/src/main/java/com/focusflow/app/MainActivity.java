package com.focusflow.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, body;
    private final ArrayList<String> tasks = new ArrayList<>();
    private final ArrayList<String> notes = new ArrayList<>();
    private int workMin = 25, shortBreak = 5, longBreak = 15, cycleCount = 4;
    private int selectedMinutes = 25;
    private final android.os.Handler stopwatchHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private long stopwatchStartedAt = 0L, stopwatchElapsed = 0L;
    private boolean stopwatchRunning = false;
    private final ArrayList<Long> stopwatchLaps = new ArrayList<>();
    private TextView stopwatchDisplay;
    private final Runnable stopwatchTick = new Runnable() { public void run() { if (stopwatchRunning && stopwatchDisplay != null) { stopwatchElapsed = System.currentTimeMillis() - stopwatchStartedAt; stopwatchDisplay.setText(formatElapsed(stopwatchElapsed)); stopwatchHandler.postDelayed(this,100); } } };
    private String theme = "Midnight", accent = "#B7E4C7";
    private String wallpaperUri = "";
    private final int bg = Color.rgb(18,20,25), panel = Color.rgb(34,37,45), fg = Color.WHITE;
    private final android.content.SharedPreferences prefs() { return getSharedPreferences("focusflow", MODE_PRIVATE); }

    @Override public void onCreate(Bundle b) { super.onCreate(b); loadPrefs(); showHome(); if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},9001); }
    private void loadPrefs() {
        theme = prefs().getString("theme","Midnight"); accent = prefs().getString("accent","#B7E4C7");
        wallpaperUri = prefs().getString("wallpaper","");
        workMin = prefs().getInt("work",25); shortBreak = prefs().getInt("short",5);
        longBreak = prefs().getInt("long",15); cycleCount = prefs().getInt("cycles",4);
        String raw = prefs().getString("tasks","[]");
        try { org.json.JSONArray a = new org.json.JSONArray(raw); for(int i=0;i<a.length();i++) tasks.add(a.getString(i)); } catch(Exception ignored){}
        String n = prefs().getString("notes","[]");
        try { org.json.JSONArray a = new org.json.JSONArray(n); for(int i=0;i<a.length();i++) notes.add(a.getString(i)); } catch(Exception ignored){}
    }
    private void savePrefs() {
        org.json.JSONArray a = new org.json.JSONArray(); for(String s:tasks)a.put(s);
        org.json.JSONArray n = new org.json.JSONArray(); for(String s:notes)n.put(s);
        prefs().edit().putString("theme",theme).putString("accent",accent).putString("wallpaper",wallpaperUri)
            .putInt("work",workMin).putInt("short",shortBreak).putInt("long",longBreak).putInt("cycles",cycleCount)
            .putString("tasks",a.toString()).putString("notes",n.toString()).apply();
    }
    private TextView label(String s,int size) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(fg);
        t.setPadding(8,10,8,10); return t;
    }
    private Button btn(String s,Runnable r) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v->r.run()); return b;
    }
    private LinearLayout col() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(16,10,16,12); return l; }
    private void base(String title) {
        root=col(); root.setBackgroundColor(bg);
        TextView h=label(title,26); h.setTypeface(null,1); root.addView(h);
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        nav.addView(btn("Home",this::showHome)); nav.addView(btn("Tasks",this::showTasks));
        nav.addView(btn("Insights",this::showInsights)); nav.addView(btn("Customize",this::showCustomize));
        root.addView(nav);
        ScrollView sc=new ScrollView(this); body=col(); sc.addView(body);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if (!wallpaperUri.isEmpty()) {
            try { root.setBackgroundColor(bg); root.setBackground(android.graphics.drawable.Drawable.createFromStream(getContentResolver().openInputStream(Uri.parse(wallpaperUri)),null)); }
            catch(Exception ignored) { root.setBackgroundColor(bg); }
        }
    }
    private void showHome() {
        base("FocusFlow");
        body.addView(label("Plan your work. Focus on one thing.",17));
        body.addView(label("Study timer",20));
        LinearLayout presets=new LinearLayout(this);
        for(int m:new int[]{15,25,45,60}) presets.addView(btn(m+"m",()->{selectedMinutes=m;showHome();}));
        body.addView(presets);
        body.addView(label("Selected: "+selectedMinutes+" minutes",15));
        body.addView(btn("Start study timer + floating pill",()->startTimer(selectedMinutes*60L,false)));
        body.addView(label("Pomodoro · "+workMin+" min work / "+shortBreak+" min break",18));
        body.addView(btn("Start Pomodoro",()->startTimer(workMin*60L,true)));
        body.addView(btn("Customize Pomodoro",this::pomodoroSettings));
        body.addView(label("AI study coach",20));
        body.addView(label("Starter guidance: choose one specific task, make the first step tiny, and begin. After the session, record what you completed. AI provider integration can be configured in a later release.",15));
        body.addView(btn("Add a session note",this::addNote));
        body.addView(btn("Open stopwatch",this::showStopwatch));
        body.addView(btn("Request floating timer permission",this::overlayPermission));
    }
    private void startTimer(long seconds,boolean pomodoro) {
        if(!Settings.canDrawOverlays(this)){overlayPermission(); Toast.makeText(this,"Allow Display over other apps, then start again.",Toast.LENGTH_LONG).show();return;}
        Intent i=new Intent(this,FloatingTimerService.class); i.putExtra("seconds",seconds); i.putExtra("pomodoro",pomodoro); i.putExtra("shortBreakSeconds",shortBreak*60); i.putExtra("longBreakSeconds",longBreak*60); i.putExtra("cycles",cycleCount);
        if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        Toast.makeText(this,"Focus timer started",Toast.LENGTH_SHORT).show();
    }
    private void overlayPermission() {
        if(!Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
        else Toast.makeText(this,"Overlay permission is enabled",Toast.LENGTH_SHORT).show();
    }
    private void pomodoroSettings() {
        LinearLayout l=col();
        EditText w=edit("Work minutes",workMin), s=edit("Short break minutes",shortBreak), lo=edit("Long break minutes",longBreak), c=edit("Work sessions per cycle",cycleCount);
        l.addView(w);l.addView(s);l.addView(lo);l.addView(c);
        new AlertDialog.Builder(this).setTitle("Pomodoro settings").setView(l).setPositiveButton("Save",(d,x)->{
            workMin=valid(w,25,1,180);shortBreak=valid(s,5,1,60);longBreak=valid(lo,15,1,90);cycleCount=valid(c,4,2,12);savePrefs();showHome();
        }).setNegativeButton("Cancel",null).show();
    }
    private EditText edit(String hint,int val){EditText e=new EditText(this);e.setSingleLine();e.setInputType(2);e.setHint(hint);e.setText(""+val);return e;}
    private int valid(EditText e,int def,int min,int max){try{return Math.max(min,Math.min(max,Integer.parseInt(e.getText().toString())));}catch(Exception ex){return def;}}
    private void showTasks() {
        base("Tasks");
        EditText e=new EditText(this);e.setHint("e.g. Maths — trigonometry exercises");body.addView(e);
        body.addView(btn("Add task",()->{String s=e.getText().toString().trim();if(!s.isEmpty()){tasks.add(s);savePrefs();showTasks();}}));
        if(tasks.isEmpty())body.addView(label("No tasks yet. Add one small, clear task.",16));
        for(int i=0;i<tasks.size();i++){final int ix=i;LinearLayout row=new LinearLayout(this);
            TextView t=label("• "+tasks.get(i),15);row.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(btn("Done",()->{tasks.remove(ix);savePrefs();showTasks();}));body.addView(row);}
    }
    private void showStopwatch() {
        base("Stopwatch");
        stopwatchDisplay = label(formatElapsed(stopwatchElapsed), 32); stopwatchDisplay.setGravity(Gravity.CENTER); body.addView(stopwatchDisplay);
        LinearLayout controls = new LinearLayout(this);
        controls.addView(btn(stopwatchRunning ? "Pause" : "Start", () -> {
            if (stopwatchRunning) { stopwatchElapsed = System.currentTimeMillis() - stopwatchStartedAt; stopwatchRunning = false; stopwatchHandler.removeCallbacks(stopwatchTick); }
            else { stopwatchStartedAt = System.currentTimeMillis() - stopwatchElapsed; stopwatchRunning = true; }
            showStopwatch();
        }));
        controls.addView(btn("Lap", () -> { if (stopwatchRunning) { stopwatchElapsed = System.currentTimeMillis() - stopwatchStartedAt; stopwatchLaps.add(stopwatchElapsed); showStopwatch(); } }));
        controls.addView(btn("Reset", () -> { stopwatchRunning = false; stopwatchHandler.removeCallbacks(stopwatchTick); stopwatchElapsed = 0; stopwatchLaps.clear(); showStopwatch(); }));
        body.addView(controls);
        for (int i=0;i<stopwatchLaps.size();i++) body.addView(label("Lap "+(i+1)+" — "+formatElapsed(stopwatchLaps.get(i)),15));
        if (stopwatchRunning) { stopwatchHandler.removeCallbacks(stopwatchTick); stopwatchHandler.post(stopwatchTick); }
    }
    private String formatElapsed(long ms) { long cs=(ms%1000)/10, sec=(ms/1000)%60, min=(ms/60000)%60, hr=ms/3600000; return String.format(Locale.US,"%02d:%02d:%02d.%02d",hr,min,sec,cs); }
    private void showInsights() {
        base("Insights");
        body.addView(label("Progress analytics",20));
        body.addView(label("Tasks currently open: "+tasks.size(),17));
        body.addView(label("Focus session history and weekly analytics will be connected to the timer session database in the next implementation pass.",15));
        body.addView(btn("Export data backup",this::exportBackup));
        body.addView(btn("Restore from backup JSON",this::importBackup));
    }
    private void showCustomize() {
        base("Customize");
        body.addView(label("Themes & wallpapers",20));
        body.addView(btn("Midnight theme",()->setTheme("Midnight","#B7E4C7")));
        body.addView(btn("Forest theme",()->setTheme("Forest","#A7E8B5")));
        body.addView(btn("Light theme",()->setTheme("Light","#4263EB")));
        body.addView(btn("Choose wallpaper from gallery",()->pickWallpaper()));
        body.addView(btn("Import customization JSON",()->importConfig()));
        body.addView(btn("Export customization JSON",()->exportConfig()));
        body.addView(btn("Restore default appearance",()->{theme="Midnight";accent="#B7E4C7";wallpaperUri="";savePrefs();showCustomize();}));
        body.addView(label("Configuration files change supported settings only; they cannot install code or add new native capabilities.",14));
    }
    private void setTheme(String t,String a){theme=t;accent=a;savePrefs();showCustomize();}
    private final int PICK_WALLPAPER=4101, IMPORT_CONFIG=4102, EXPORT_CONFIG=4103, EXPORT_BACKUP=4104, IMPORT_BACKUP=4105;
    private void pickWallpaper(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_WALLPAPER);}
    private void importConfig(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT_CONFIG);}
    private void exportConfig(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"focusflow-customization.json");startActivityForResult(i,EXPORT_CONFIG);}
    private void exportBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"focusflow-backup.json");startActivityForResult(i,EXPORT_BACKUP);}
    private void importBackup(){new AlertDialog.Builder(this).setTitle("Restore backup?").setMessage("This replaces current tasks, notes and supported settings.").setPositiveButton("Choose backup",(d,w)->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,IMPORT_BACKUP);}).setNegativeButton("Cancel",null).show();}
    private JSONObject configJson(){
        JSONObject j=new JSONObject();try{j.put("schemaVersion",1);j.put("theme",theme);j.put("accent",accent);j.put("workMinutes",workMin);j.put("shortBreakMinutes",shortBreak);j.put("longBreakMinutes",longBreak);j.put("cycles",cycleCount);}catch(Exception ignored){}return j;
    }
    private void addNote(){
        EditText e=new EditText(this);e.setHint("What did you finish? What comes next?");
        new AlertDialog.Builder(this).setTitle("Session note").setView(e).setPositiveButton("Save",(d,w)->{String s=e.getText().toString().trim();if(!s.isEmpty()){notes.add(s);savePrefs();Toast.makeText(this,"Note saved",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();
    }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;Uri u=data.getData();
        try{
            if(req==PICK_WALLPAPER){getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);wallpaperUri=u.toString();savePrefs();showCustomize();}
            else if(req==IMPORT_CONFIG){
                String raw=read(u);JSONObject j=new JSONObject(raw);
                if(j.optInt("schemaVersion",-1)!=1)throw new Exception("Unsupported schema version");
                String th=j.optString("theme","Midnight"), ac=j.optString("accent","#B7E4C7");
                if(!Arrays.asList("Midnight","Forest","Light").contains(th))throw new Exception("Unsupported theme");
                if(!ac.matches("#[0-9A-Fa-f]{6}"))throw new Exception("Invalid accent color");
                theme=th;accent=ac;workMin=clamp(j.optInt("workMinutes",25),1,180);shortBreak=clamp(j.optInt("shortBreakMinutes",5),1,60);
                longBreak=clamp(j.optInt("longBreakMinutes",15),1,90);cycleCount=clamp(j.optInt("cycles",4),2,12);savePrefs();
                new AlertDialog.Builder(this).setTitle("Customization imported").setMessage("Supported settings were validated and applied.").setPositiveButton("OK",(d,w)->showCustomize()).show();
            } else if(req==IMPORT_BACKUP){
                JSONObject j=new JSONObject(read(u));
                if(j.optInt("backupVersion",-1)!=1 || j.optInt("schemaVersion",-1)!=1)throw new Exception("Unsupported backup format");
                String th=j.optString("theme","Midnight"), ac=j.optString("accent","#B7E4C7");
                if(!Arrays.asList("Midnight","Forest","Light").contains(th)||!ac.matches("#[0-9A-Fa-f]{6}"))throw new Exception("Invalid backup settings");
                theme=th;accent=ac;workMin=clamp(j.optInt("workMinutes",25),1,180);shortBreak=clamp(j.optInt("shortBreakMinutes",5),1,60);longBreak=clamp(j.optInt("longBreakMinutes",15),1,90);cycleCount=clamp(j.optInt("cycles",4),2,12);
                tasks.clear();notes.clear();org.json.JSONArray ta=j.optJSONArray("tasks");if(ta!=null)for(int k=0;k<ta.length();k++)tasks.add(ta.optString(k));org.json.JSONArray na=j.optJSONArray("notes");if(na!=null)for(int k=0;k<na.length();k++)notes.add(na.optString(k));
                wallpaperUri=j.optString("wallpaperUri","");savePrefs();new AlertDialog.Builder(this).setTitle("Backup restored").setMessage("Tasks, notes and supported settings restored.").setPositiveButton("OK",(d,w)->showHome()).show();
            } else if(req==EXPORT_CONFIG || req==EXPORT_BACKUP){
                JSONObject j=configJson();
                if(req==EXPORT_BACKUP){j.put("backupVersion",1);j.put("wallpaperUri",wallpaperUri);org.json.JSONArray a=new org.json.JSONArray();for(String s:tasks)a.put(s);j.put("tasks",a);org.json.JSONArray n=new org.json.JSONArray();for(String s:notes)n.put(s);j.put("notes",n);}
                try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(j.toString(2).getBytes("UTF-8"));}
                Toast.makeText(this,"Export complete",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Could not process file").setMessage(ex.getMessage()==null?"Invalid file":ex.getMessage()).setPositiveButton("OK",null).show();}
    }
    private int clamp(int n,int min,int max){return Math.max(min,Math.min(max,n));}
    private String read(Uri u)throws Exception{StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(u)))){String s;while((s=r.readLine())!=null)b.append(s);}return b.toString();}
}
