package com.focusflow.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class FloatingTimerService extends Service {
    private WindowManager wm; private View bubble; private TextView time, play;
    private WindowManager.LayoutParams params; private Handler handler=new Handler(Looper.getMainLooper());
    private long remaining=1500, endAt=0; private boolean running=true, pomodoro=false;
    private int workSeconds=1500, breakSeconds=300, longBreakSeconds=900, cycles=4, completedWorkSessions=0; private boolean onBreak=false, onLongBreak=false;
    private static final String CHANNEL="focusflow_timer";
    private final Runnable tick=new Runnable(){public void run(){
        if(running){remaining=Math.max(0,(endAt-System.currentTimeMillis()+999)/1000);
            if(remaining<=0){if(pomodoro){if(!onBreak){completedWorkSessions++;onBreak=true;onLongBreak=(completedWorkSessions%cycles==0);remaining=onLongBreak?longBreakSeconds:breakSeconds;}else{onBreak=false;onLongBreak=false;remaining=workSeconds;}endAt=System.currentTimeMillis()+remaining*1000L;notifyPhase();}
            else{running=false;play.setText("▶");notifyFinished();stopSelf();}}
            update();}
        handler.postDelayed(this,250);
    }};
    @Override public int onStartCommand(Intent in,int flags,int id){
        if(in!=null){remaining=Math.max(1,in.getLongExtra("seconds",1500));pomodoro=in.getBooleanExtra("pomodoro",false);workSeconds=(int)remaining;breakSeconds=Math.max(60,in.getIntExtra("shortBreakSeconds",300));longBreakSeconds=Math.max(60,in.getIntExtra("longBreakSeconds",900));cycles=Math.max(2,in.getIntExtra("cycles",4));completedWorkSessions=0;onBreak=false;onLongBreak=false;running=true;endAt=System.currentTimeMillis()+remaining*1000L;}
        createChannel();startForeground(41,notification("Focus session running"));
        if(bubble==null)createBubble();handler.removeCallbacks(tick);handler.post(tick);return START_NOT_STICKY;
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Focus timer",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification notification(String s){
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setContentTitle("FocusFlow").setContentText(s).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(running).build();
    }
    private void notifyPhase(){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(41,notification(onBreak?(onLongBreak?"Pomodoro long break":"Pomodoro short break"):"Pomodoro work session"));playSound();}
    private void notifyFinished(){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(42,notification("Focus session complete"));playSound();}
    private void playSound(){try{android.media.ToneGenerator t=new android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION,70);t.startTone(android.media.ToneGenerator.TONE_PROP_BEEP,250);}catch(Exception ignored){}}
    private void createBubble(){
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);
        l.setPadding(8,3,7,3);l.setBackgroundColor(Color.rgb(31,33,39));
        play=new TextView(this);play.setText("Ⅱ");play.setTextColor(Color.rgb(183,228,199));play.setTextSize(18);play.setPadding(8,4,9,4);
        time=new TextView(this);time.setTextColor(Color.WHITE);time.setTextSize(15);time.setTypeface(null,1);
        TextView close=new TextView(this);close.setText("×");close.setTextColor(Color.LTGRAY);close.setTextSize(20);close.setPadding(10,0,3,0);
        l.addView(play);l.addView(time);l.addView(close);
        play.setOnClickListener(v->{if(running){remaining=Math.max(0,(endAt-System.currentTimeMillis()+999)/1000);running=false;play.setText("▶");}
            else if(remaining>0){running=true;endAt=System.currentTimeMillis()+remaining*1000L;play.setText("Ⅱ");}update();});
        close.setOnClickListener(v->stopSelf());
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.END;params.x=14;params.y=180;
        l.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int px,py;long down;
            public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:sx=e.getRawX();sy=e.getRawY();px=params.x;py=params.y;down=System.currentTimeMillis();return false;
                case MotionEvent.ACTION_MOVE:if(Math.abs(e.getRawX()-sx)>8||Math.abs(e.getRawY()-sy)>8){params.x=px+(int)(sx-e.getRawX());params.y=py+(int)(e.getRawY()-sy);try{wm.updateViewLayout(l,params);}catch(Exception ignored){}return true;}break;
            }return false;}});
        bubble=l;try{wm.addView(bubble,params);}catch(Exception e){stopSelf();}
        update();
    }
    private void update(){if(time!=null)time.setText(String.format(Locale.US,"%02d:%02d",remaining/60,remaining%60));}
    @Override public void onDestroy(){handler.removeCallbacks(tick);if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}
        bubble=null;stopForeground(true);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
