# Build the FocusFlow APK

This source project includes a GitHub Actions workflow that builds a debug APK in a hosted Android build environment. This chat environment does not have the Android SDK/Gradle and cannot compile or test the APK directly.

## Steps
1. Create a new repository on GitHub and upload the contents of this folder (not the ZIP itself). Keep `.github/workflows/build-apk.yml` in the repository.
2. Open the repository's **Actions** tab and select **Build FocusFlow APK**.
3. Press **Run workflow** (or push the source to `main`/`master`, which triggers the workflow).
4. Open the completed workflow run. Under **Artifacts**, download **FocusFlow-debug-apk**.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer it to your Android phone and tap it to install. If Android asks, allow installation from the file manager you used.

This is a debug build, not a Play Store release. The workflow must complete successfully before an APK is available. The app is an early prototype; not every planned feature is complete or device-tested.
