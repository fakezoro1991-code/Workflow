# FocusFlow Android starter project

This is the initial native Android source project for the agreed FocusFlow specification.

## Included in this initial implementation
- Native Android Java project with Gradle configuration
- Study timer presets
- Compact draggable floating timer pill with play/pause, remaining time, and close
- Notification while the timer service runs
- Pomodoro duration settings and basic work/break switching
- Basic task list with local persistence
- Theme presets and wallpaper selection
- Versioned JSON customization import/export with validation
- Basic session notes
- Basic backup export
- Insights screen scaffold
- Home-screen widget scaffold
- Basic offline study guidance

## Not yet complete
This is an early implementation scaffold, not a production-ready release. The following need further implementation and testing:
- Live stopwatch with lap support
- Full timer/session history and accurate analytics
- Complete backup and restore (including restore workflow)
- Robust Pomodoro cycle logic and session completion logging
- Proper theme colors applied throughout every screen
- Wallpaper cropping/dimming and per-screen wallpaper choices
- Widget quick actions and live timer display
- Real AI provider integration (requires a provider choice and secure API design)
- Android 13+ notification permission request flow
- Accessibility, battery, lifecycle and real-device QA
- Signing and final APK generation

## Build requirements
This environment did not have the Android SDK, Gradle, or ADB installed, so an APK has not been compiled or tested here.

1. Install Android Studio on a computer.
2. Open this folder as a Gradle project.
3. Install Android SDK Platform 35 and a compatible JDK through Android Studio.
4. Sync Gradle and resolve any SDK/toolchain prompts.
5. Build > Build APK(s).
6. Install the APK on your Android device and test overlay permission, notification behavior and background timing.

The app requests the "Display over other apps" permission only when you choose to use the floating timer. AI functionality is a placeholder until an AI provider is selected.
